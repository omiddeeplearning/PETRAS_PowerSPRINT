import { Col, Row, Image } from 'antd'
import React from 'react'
import img1 from '../Images/Multi_Img1.png'
import img2 from '../Images/Multi_Img3.png'
import img3 from '../Images/Multi_Img2.png'
import defautlImg from '../Images/IEEE_39_Bus.png'
import testImage from '../Images/IEEE-39 bus summary.png'
const Option1 = () => {
  return (
    <>
      <Row>
        <Col xl={7} lg={7} md={7} sm={7} xs={24}>
          <Image src={img1}></Image>
          <p>
            <b>Confusion matrix of 2DR-CNN for IEEE 39-bus</b>
          </p>
        </Col>
        <Col xl={1} lg={1} md={1} sm={1}></Col>
        <Col xl={7} lg={7} md={7} sm={7} xs={24}>
          <Image src={img3}></Image>
          <p>
            <b>Frequency and Phase Angle profiles for IEEE 39-bus</b>
          </p>
          <Image src={img2}></Image>
        </Col>
        <Col xl={1} lg={1} md={1} sm={1}></Col>
        <Col xl={7} lg={7} md={7} sm={7} xs={24}>
          <Image
            style={{
              width: '250px',
            }}
            src={defautlImg}
            alt='deafult'
          />
          <p>
          <b>IEEE 39-bus</b>
        </p>
        <img
            style={{
              paddingTop: '20x',
              width: '300px',
              height:'125px'
            }}
            src={testImage}
            alt=''
          /> <p>
          <b>IEEE 39-bus summary</b>
        </p>

        </Col>
      </Row>
    </>
  )
}

export default Option1
