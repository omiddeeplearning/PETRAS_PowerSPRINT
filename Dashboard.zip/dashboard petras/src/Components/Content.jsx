import { Card, Select } from 'antd'
import React, { useState } from 'react'
import Option1 from './Option1'
import Option2 from './Option2'
import Option3 from './Option3'
import Option4 from './Option4'
import Option5 from './Option5'
import Option6 from './Option6'
const Content = () => {
  const [selectVlaue, setSelectVlaue] = useState(null)
  const handleChange = (e) => {
    // console.log('This is E', e)
    setSelectVlaue(e)
  }

  return (
    <>
      <Card>
        <Select
          placeholder='Please Select Option'
          style={{
            width: '100%',
            paddingBottom: '10px',
          }}
          onSelect={handleChange}
          defaultOpen={false}
        >
          <Select.Option value={1}>
            IEEE 39-bus Case (Multi-point Attacks)
          </Select.Option>
          <Select.Option value={2}>
            IEEE 39-bus Case (Single-point Attacks)
          </Select.Option>
          <Select.Option value={3}>
            IEEE 57-bus Case (Single-point Attacks)
          </Select.Option>
          <Select.Option value={4}>
            IEEE 57-bus Case (Multi-point Attacks)
          </Select.Option>
          <Select.Option value={5}>
            IEEE 14-bus Case (Single-point-Attacks)
          </Select.Option>
          <Select.Option value={6}>
            IEEE 14-bus Case (Multi-point-Attacks)
          </Select.Option>
        </Select>
        {selectVlaue === 1 && (
          <>
            <Option1></Option1>
          </>
        )}
        {selectVlaue === 2 && (
          <>
            <Option2></Option2>
          </>
        )}
        {selectVlaue === 3 && (
          <>
            <Option3></Option3>
          </>
        )}
        {selectVlaue === 4 && (
          <>
            <Option4></Option4>
          </>
        )}
        {selectVlaue === 5 && (
          <>
            <Option5></Option5>
          </>
        )}
        {selectVlaue === 6 && (
          <>
            <Option6></Option6>
          </>
        )}
      </Card>
    </>
  )
}

export default Content
