import React from 'react'
import uniLogo from './Images/warwick_web_1.webp'
import petrasLogo from './Images/petras_logo.png'
import './app.css'
import Content from './Components/Content'
import { Col, Row } from 'antd'

const App = () => {
  return (
    <>
      <header>
        <Row>
          <Col xl={8} lg={7} md={7} sm={7} xs={24}>
            <h1>
              Power Grid IoT System <br /> Protection and Resilience using{' '}
              <br />
              Intelligent Edge (Power-SPRINT)
            </h1>
          </Col>
          <Col xl={1} lg={1} md={1} sm={1}></Col>
          <Col xl={8} lg={7} md={7} sm={1} xs={24}>
            <img alt='Uni Logo' style={{
              width: '250px'
    
            }}src={uniLogo}></img>
          </Col>
          <Col xl={1} lg={1} md={1} sm={1}></Col>
          <Col xl={5} lg={7} md={7} sm={7} xs={24}>
            <img alt='Petras Logo' src={petrasLogo}></img>
          </Col>
        </Row>
      </header>
      <article>
        <Content></Content>
      </article>
    </>
  )
}

export default App
